package com.itea.dimka.lection8.task3;

public class ActionRun {
    public static void main(String[] args) {
        Account account= new Account();
        account.addAction();
        System.out.println(account);
    }
}
