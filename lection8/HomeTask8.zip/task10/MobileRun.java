package com.itea.dimka.lection8.task10;

public class MobileRun {
    public static void main(String[] args) {
        Mobile mobile = new Mobile();
        mobile.printRes();
    }
}
