package com.itea.dimka.lection8.task8;

public class CityRun {
    public static void main(String[] args) {
        City city = new City();
        city.printInfo();
    }
}
