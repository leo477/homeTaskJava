package com.itea.dimka.lection8.task9;

public class BlueRayDiscRun {
    public static void main(String[] args) {
        BlueRayDisc.DiscInfo discInfo = new BlueRayDisc().new DiscInfo();
        discInfo.printRes();
    }
}
