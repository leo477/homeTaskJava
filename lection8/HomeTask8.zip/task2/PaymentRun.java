package com.itea.dimka.lection8.task2;

public class PaymentRun {
    public static void main(String[] args) {
        Payment payment = new Payment();
        payment.sellProducts();
    }
}
