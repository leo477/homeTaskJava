package com.itea.dimka.lection8.task8;

public interface CityInfo {

    void setName(String name);

    void setFirstNumber(int firstNumber);

    void setLastNumber(int lastNumber);

//    int getFirstNumber();
//    int getLastNumber();
}
