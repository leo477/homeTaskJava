package com.itea.dimka.lection8.task7;

public class EuropeRun {
    public static void main(String[] args) {
        Europe europe= new Europe();
        europe.printChanging();
    }
}
